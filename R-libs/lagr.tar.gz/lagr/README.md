lager
=====

Local, adaptive, grouped regularization
